// Klistra in din fullständiga App.tsx här (från canvas)
